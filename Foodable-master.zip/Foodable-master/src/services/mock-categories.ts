export let CATEGORIES = [
  {
    id: 1,
    name: "Asian Food",
    image: "http://img.huffingtonpost.com/asset/scalefit_970_noupscale/585be1aa1600002400bdf2a6.jpeg"
    
  },

  {
    id: 2,
    name: "American Food",
    image: "https://img.grouponcdn.com/deal/k3EyCBD149fq3nSARny/ft-2048x1229/v1/c700x420.jpg"
    
  },

  {
    id: 3,
    name: "Mexican Food",
    image: "http://wooderice.com/wp-content/uploads/2014/09/mexicanfood.jpg"
    
  },

  {
    id: 4,
    name: "Colombian Food",
    image: "https://images.latintravelguide.com/w700/colombian-food-and-drink-colombia-food-drink-61.jpg"
    
  },

  {
    id: 5,
    name: "Jamaican Food",
    image: "https://img.grouponcdn.com/iam/4joKLGeb6PmWXWquFzHt/3o-2048x1229/v1/c700x420.jpg"
    
  },
  
]
