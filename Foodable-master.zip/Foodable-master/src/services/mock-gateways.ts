export let GATEWAYS = [
  
]